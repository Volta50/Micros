// =============================================================================
//  GUIA 4 ACTUALIZADA: Contador con HC-SR04 + LCD + BCD + RGB + Buzzer + HLVD
//  + Bienvenida con caracter propio (fantasma flotando), efectos de
//    desplazamiento derecha/izquierda y cursor apagado. Solo al inicio.
//  + Tecla de backlight (ON/OFF), auto-apagado de luz a 10 s de inactividad
//    y suspension total (SLEEP) a 20 s. La actividad (tecla o deteccion de
//    pieza) reinicia el temporizador. El conteo arranca al salir de la
//    bienvenida.
//
//  CAMBIOS RESPECTO A LA GUIA 4 ORIGINAL:
//   - Sensor IR (RC1, polling) reemplazado por HC-SR04 (TRIGGER=RC0, ECHO=RC1
//     con captura por CCP2 + Timer1). Una pieza se cuenta cuando SALE del
//     rango [DIST_MIN_CM, DIST_MAX_CM] (equivalente al flanco de bajada IR).
//   - LED indicador movido de RA0 a RA6 (pinout Guia 5).
//   - FOSC: INTOSC_HS -> INTOSCIO_EC (necesario para usar RA6 como I/O).
//   - TRISA = 0b00000011 (RA0, RA1 como entradas, reservadas/compat. Guia 5).
//   - Anadido Timer1 (sin prescaler) para medir el ancho del pulso ECHO.
//
//  PIC18F4550
//  Oscilador: INTERNO 1 MHz
//    FOSC  = INTOSCIO_EC     -> RA6 disponible como I/O (LED indicador)
//    OSCCON = 0b01000011     -> IRCF=100 (1 MHz) + SCS=11 (fuerza interno)
//
//  Timer0 -> prescaler 1:8, 16 bits, Fciclo = 250 kHz:
//    Conmutacion 1 s   -> TMR0 reload = 34286  (65536 - 31250)
//    Conmutacion 250ms -> TMR0 reload = 57724  (65536 -  7812)  [alerta HLVD]
//
//  Timer1 -> medicion del ECHO del HC-SR04 (sin prescaler, 4 us por tick).
//    1 cm round-trip ~= 58 us ~= 14.5 ticks => dist_cm = CCPR2 / 14
// =============================================================================
//  Pines (compatibles con Guia 5):
//    RA0/AN0 -> sin usar (entrada, reservado pinout Guia 5)
//    RA1/AN1 -> sin usar (entrada; potenciometro en Guia 5)
//    RA2  -> Backlight LCD (BLK, salida activo-alto)
//    RA3  -> Buzzer  (salida activo-alto)
//    RA4  -> LCD E
//    RA5  -> LCD RS
//    RA6  -> LED indicador (conmuta con Timer0, salida activo-alto)
//    RB4-RB7 -> Filas del teclado matricial (entradas con pull-up)
//    RB0-RB3 -> Columnas del teclado matricial (salidas)
//    RC0  -> HC-SR04 TRIGGER (salida)
//    RC1  -> HC-SR04 ECHO    (entrada, capturada por CCP2)
//    RD0-RD3 -> Salida BCD (unidades del counter)
//    RD4-RD7 -> Datos LCD (interfaz 4 bits)
//    RE0-RE2 -> RGB LED (anodo comun, activo bajo)
//    RE3  -> entrada MCLR / no usada
// =============================================================================

#include <xc.h>
#define _XTAL_FREQ 1000000

#define RS    LATA5
#define E     LATA4
#include "LibLCDXC8.h"

// -- Conexiones del HC-SR04 ---------------------------------------------------
#define TRIGGER LATCbits.LATC0   // TRIGGER en RC0
#define ECHO    PORTCbits.RC1    // ECHO en RC1

// -- Codigo de la tecla que conmuta el backlight ------------------------------
#define TECLA_BACKLIGHT 13

// -- Umbrales de inactividad (en ms) ------------------------------------------
#define MS_APAGA_LUZ    10000U   // 10 s -> apaga backlight
#define MS_SUSPENSION   20000U   // 20 s -> suspension total (SLEEP)

// -- Rango de deteccion del HC-SR04 (en cm) -----------------------------------
//  Una pieza se considera "presente" si la distancia esta en este rango.
//  El conteo se produce cuando la pieza SALE del rango (estilo flanco de
//  bajada del IR original).
#define DIST_MIN_CM     5
#define DIST_MAX_CM     8

// -- Fuses --------------------------------------------------------------------
#pragma config FOSC   = INTOSCIO_EC   // oscilador interno, RA6 como I/O
#pragma config WDT    = OFF
#pragma config BOR    = OFF           // HLVD se encarga de la deteccion de bajo V
#pragma config PBADEN = OFF
#pragma config MCLRE  = ON            // RE3 actua como MCLR
#pragma config LVP    = OFF

// -- Variables globales -------------------------------------------------------
volatile unsigned char Tecla = 0;
volatile unsigned char TeclaLista = 0;
volatile unsigned char counter = 0;
volatile unsigned char tens = 0;
volatile unsigned char FinalizarConteo = 0;
volatile unsigned char ReiniciarConteo = 0;
volatile unsigned char ringRing = 0;
volatile unsigned char rangRang = 0;
volatile unsigned char initialized = 0;

volatile unsigned int tmr0_reload = 34286;

// -- BONUS 2: gestion de inactividad / suspension -----------------------------
volatile unsigned int tiempoInactivo = 0; // ms acumulados por Timer0
volatile unsigned char backlightOn = 1; // estado DESEADO del BLK (RA2)
volatile unsigned char enSuspension = 0; // 1 mientras el sistema duerme

// -- Estado de la deteccion del objeto (HC-SR04) ------------------------------
//   0 = objeto NO presente en el rango (lejos o sin eco)
//   1 = objeto presente en [DIST_MIN_CM, DIST_MAX_CM]
volatile unsigned char estadoObjeto = 0;

// =============================================================================
//  BONUS: Caracteres propios en CGRAM - fantasma con 2 cuadros de animacion
// =============================================================================

// Fantasma 5x8 - cuadro 0: posicion ALTA (flotando arriba)
const unsigned char fantasmaArriba[8] = {
    0b01110, //  ###   <- cupula de la cabeza
    0b11111, // #####
    0b10101, // # # #  <- ojos
    0b11111, // #####
    0b11111, // #####  <- cuerpo
    0b11111, // #####
    0b10101, // # # #  <- falda ondulada (picos en extremos)
    0b00000 //        <- fila libre (espacio para "bajar")
};

// Fantasma 5x8 - cuadro 1: posicion BAJA (bajado 1 pixel, falda alternada)
const unsigned char fantasmaAbajo[8] = {
    0b00000, //        <- fila libre (el fantasma bajo)
    0b01110, //  ###
    0b11111, // #####
    0b10101, // # # #  <- ojos
    0b11111, // #####
    0b11111, // #####
    0b11111, // #####
    0b01010 //  # #   <- falda ondulada (picos al centro = ondeo)
};

// -- Prototipos ----------------------------------------------------------------
void ActualizaLCD(unsigned char objetivo, unsigned char contadas);
void buzz(unsigned char shortBuzz);
void setRGB(void);
void CreaCaracter(unsigned char pos, const unsigned char *mapa);
void EntrarSuspension(void);
unsigned char MedirDistancia(void);
void interrupt ISR(void);

// =============================================================================
//  MAIN
// =============================================================================

void main(void) {
    unsigned char digitoBuf[2] = {0xFF, 0xFF};
    unsigned char numDigitos = 0;
    unsigned char cuentaObjetivo = 0;
    unsigned char valorTemporal;
    unsigned char paso, cuadro = 0; // BONUS: animacion de bienvenida

    // -- Oscilador interno 1 MHz - PRIMERO, antes de cualquier delay o IRQ ----
    //OSCCON = 0b01000011;
    while (!OSCCONbits.IOFS); // Esperar oscilador interno estable

    // -- Prioridades de interrupcion ------------------------------------------
    IPEN = 1;
    PEIE = 1;
    GIE = 1;

    // -- Puertos analogicos -> digitales --------------------------------------
    //  Aqui no se usa ADC (a diferencia de la Guia 5), asi que dejamos todo
    //  digital. RA0/RA1 quedan como entradas para no chocar si hay cableado
    //  de potenciometro/analogicos del montaje de Guia 5.
    ADCON1 = 0x0F;

    // -- PORTA: RA0/RA1 entradas, RA2-RA6 salidas, RA7 sin usar ----------------
    TRISA = 0b00000011;
    LATA = 0;
    LATA2 = 1; // Backlight encendido al arranque

    // -- PORTB: teclado matricial ----------------------------------------------
    TRISB = 0b11110000;
    LATB = 0b00000000;
    RBPU = 0; // Activa los pullups en el puerto B

    // -- PORTC: HC-SR04 (RC0 TRIGGER salida, RC1 ECHO entrada) -----------------
    TRISC = 0b00000010;
    LATC = 0b00000000;
    TRIGGER = 0;

    // -- PORTD: BCD (D0-D3) + datos LCD (D4-D7) --------------------------------
    TRISD = 0;
    LATD = 0;

    // -- PORTE: RGB LED (anodo comun, activo bajo) en RE0-RE2 ------------------
    TRISE = 0b1000; // RE3 entrada, RE2:RE0 salidas
    LATE = 0b1111; // RGB apagado (todo en '1')

    // -- Timer0: prescaler 1:8, 16 bits ----------------------------------------
    TMR0 = tmr0_reload;
    T0CON = 0b00000010;
    TMR0IF = 0;
    TMR0IE = 1;
    TMR0IP = 1;
    TMR0ON = 1;

    // -- Timer1: medicion del eco del HC-SR04 ----------------------------------
    //  Sin prescaler -> ticks de Tcy = 4 us a Fosc = 1 MHz.
    //  Se enciende y apaga puntualmente dentro de MedirDistancia().
    T1CON = 0b10000000;

    // -- HLVD: detectar caida a ~4 V -------------------------------------------
    HLVDCON = 0b00001100;
    HLVDEN = 1;
    while (!IRVST);
    HLVDIF = 0;
    HLVDIE = 1;
    HLVDIP = 1;

    // -- INT0: no usado ----------------------------------------------------------
    INT0IF = 0;

    // -- Interrupcion por cambio en PORTB (teclado) -------------------------------
    __delay_ms(100);
    RBIF = 0;
    RBIE = 1;

    // -- Inicializar LCD ----------------------------------------------------------
    __delay_ms(1000);
    ConfiguraLCD(4);
    InicializaLCD();

    // =========================================================================
    //  BONUS: BIENVENIDA con fantasma flotando + desplazamientos + cursor OFF
    //  (solo se ejecuta al encender: queda antes de MENU_OBJETIVO)
    // =========================================================================

    // -- Cursor apagado ----------------------------------------------------------
    // InicializaLCD() deja 0x0F (display ON + cursor ON + blink ON).
    // 0x0C = display ON, cursor OFF, parpadeo OFF.
    ComandoLCD(0x0C);

    // -- Cargar fantasma (2 cuadros de animacion) en CGRAM ------------------------
    CreaCaracter(0, fantasmaArriba); // caracter propio 0
    CreaCaracter(1, fantasmaAbajo); // caracter propio 1

    // -- Mensaje de bienvenida + fantasmas ----------------------------------------
    // Linea 1: "Un dia mas" + fantasma en 0x8B
    DireccionaLCD(0x80);
    EscribeLCD_c('U');
    EscribeLCD_c('n');
    EscribeLCD_c(' ');
    EscribeLCD_c('d');
    EscribeLCD_c('i');
    EscribeLCD_c('a');
    EscribeLCD_c(' ');
    EscribeLCD_c('m');
    EscribeLCD_c('a');
    EscribeLCD_c('s');
    DireccionaLCD(0x8B);
    EscribeLCD_c(0); // fantasma (cuadro arriba)

    // Linea 2: "un dia menos" + fantasma en 0xCD
    DireccionaLCD(0xC0);
    EscribeLCD_c('u');
    EscribeLCD_c('n');
    EscribeLCD_c(' ');
    EscribeLCD_c('d');
    EscribeLCD_c('i');
    EscribeLCD_c('a');
    EscribeLCD_c(' ');
    EscribeLCD_c('m');
    EscribeLCD_c('e');
    EscribeLCD_c('n');
    EscribeLCD_c('o');
    EscribeLCD_c('s');
    DireccionaLCD(0xCD);
    EscribeLCD_c(1); // fantasma (cuadro abajo)

    __delay_ms(800); // ver el mensaje quieto un momento

    // -- Animacion: desplazamiento D/I con fantasma flotando ----------------------
    cuadro = 0;
    for (paso = 0; paso < 16; paso++) {

        // Animar el fantasma (alterna arriba <-> abajo, en contrafase)
        DireccionaLCD(0x8B);
        EscribeLCD_c(cuadro); // 0 o 1
        DireccionaLCD(0xCD);
        EscribeLCD_c(cuadro ^ 1); // el otro cuadro
        cuadro ^= 1;

        // Desplazar la pantalla: 4 a la derecha, 4 a la izquierda, repetir.
        if ((paso & 0x04) == 0)
            ComandoLCD(0x1C); // desplaza pantalla a la DERECHA
        else
            ComandoLCD(0x18); // desplaza pantalla a la IZQUIERDA

        __delay_ms(300);
    }

    // =========================================================================
    //  MENU OBJETIVO
    // =========================================================================

    LATE = 0b1111;

MENU_OBJETIVO:

    digitoBuf[0] = 0xFF;
    digitoBuf[1] = 0xFF;
    numDigitos = 0;
    cuentaObjetivo = 0;
    counter = 0;
    tens = 0;
    FinalizarConteo = 0;
    ReiniciarConteo = 0;
    TeclaLista = 0;
    estadoObjeto = 0;
    LATD = 0;
    initialized = 0;

    // -- BONUS 2: arrancar la cuenta de inactividad AQUI (post-bienvenida) -----
    tiempoInactivo = 0;
    backlightOn = 1;
    LATA2 = 1; // luz encendida al entrar al menu

    BorraLCD();
    EscribeLCD_c('D');
    EscribeLCD_c('i');
    EscribeLCD_c('g');
    EscribeLCD_c('i');
    EscribeLCD_c('t');
    EscribeLCD_c('e');
    EscribeLCD_c(' ');
    EscribeLCD_c('l');
    EscribeLCD_c('a');
    EscribeLCD_c(' ');
    EscribeLCD_c('c');
    EscribeLCD_c('u');
    EscribeLCD_c('e');
    EscribeLCD_c('n');
    EscribeLCD_c('t');
    EscribeLCD_c('a');
    DireccionaLCD(0xC0);
    EscribeLCD_c('o');
    EscribeLCD_c('b');
    EscribeLCD_c('j');
    EscribeLCD_c('e');
    EscribeLCD_c('t');
    EscribeLCD_c('i');
    EscribeLCD_c('v');
    EscribeLCD_c('o');
    EscribeLCD_c(':');
    EscribeLCD_c(' ');
    EscribeLCD_c('_');
    EscribeLCD_c('_');

    // -- Captura numero objetivo (1-59) -----------------------------------------
    while (cuentaObjetivo == 0) {

        // -- Gestion de inactividad tambien en el menu objetivo -----------------
        if (tiempoInactivo >= MS_SUSPENSION) {
            EntrarSuspension();
        } else if (tiempoInactivo >= MS_APAGA_LUZ && LATA2 == 1) {
            LATA2 = 0; // apaga backlight (auto), conserva backlightOn
        }

        if (TeclaLista) {
            TeclaLista = 0;
            unsigned char t = Tecla;

            if (t == 10) {
                if (numDigitos == 1) valorTemporal = digitoBuf[0];
                else if (numDigitos == 2) valorTemporal = digitoBuf[0] * 10 + digitoBuf[1];
                else valorTemporal = 0;

                if (valorTemporal >= 1 && valorTemporal <= 59) {
                    cuentaObjetivo = valorTemporal;
                    DireccionaLCD(0xCC);
                    EscribeLCD_c('O');
                    EscribeLCD_c('K');
                    __delay_ms(1000);
                } else {
                    DireccionaLCD(0xCA);
                    EscribeLCD_c('E');
                    EscribeLCD_c('R');
                    EscribeLCD_c('R');
                    __delay_ms(1500);
                    DireccionaLCD(0xCA);
                    EscribeLCD_c('_');
                    EscribeLCD_c('_');
                    EscribeLCD_c(' ');
                    numDigitos = 0;
                    digitoBuf[0] = 0xFF;
                    digitoBuf[1] = 0xFF;
                }

            } else if (t == 12) {
                if (numDigitos > 0) {
                    numDigitos--;
                    digitoBuf[numDigitos] = 0xFF;
                    DireccionaLCD(0xC9 + numDigitos + 1);
                    EscribeLCD_c('_');
                }

            } else if (t <= 9 && numDigitos < 2) {
                digitoBuf[numDigitos] = t;
                numDigitos++;
                DireccionaLCD(0xC9 + numDigitos);
                EscribeLCD_c('0' + t);
            }
        }
    }

    // -- Pantalla de conteo --------------------------------------------------------
    BorraLCD();

    DireccionaLCD(0x80);
    EscribeLCD_c('P');
    EscribeLCD_c('i');
    EscribeLCD_c('e');
    EscribeLCD_c('z');
    EscribeLCD_c('a');
    EscribeLCD_c('s');
    EscribeLCD_c(' ');
    EscribeLCD_c('f');
    EscribeLCD_c('a');
    EscribeLCD_c('l');
    EscribeLCD_c('t');
    EscribeLCD_c(':');
    EscribeLCD_c(' ');
    EscribeLCD_c('_');
    EscribeLCD_c('_');

    DireccionaLCD(0xC0);
    EscribeLCD_c('C');
    EscribeLCD_c('u');
    EscribeLCD_c('e');
    EscribeLCD_c('n');
    EscribeLCD_c('t');
    EscribeLCD_c('a');
    EscribeLCD_c(' ');
    EscribeLCD_c('o');
    EscribeLCD_c('b');
    EscribeLCD_c('j');
    EscribeLCD_c('.');
    EscribeLCD_c(':');
    EscribeLCD_c(' ');
    if (cuentaObjetivo >= 10) {
        EscribeLCD_c('0' + (cuentaObjetivo / 10));
        EscribeLCD_c('0' + (cuentaObjetivo % 10));
    } else {
        EscribeLCD_c(' ');
        EscribeLCD_c('0' + cuentaObjetivo);
    }

    // -- Bucle principal de conteo ---------------------------------------------------
    unsigned char counterAnterior = 0xFF;

    while (1) {

        // -- Gestion de inactividad en el conteo -------------------------------
        if (tiempoInactivo >= MS_SUSPENSION) {
            EntrarSuspension();
            counterAnterior = 0xFF; // forzar refresco del numero al volver
        } else if (tiempoInactivo >= MS_APAGA_LUZ && LATA2 == 1) {
            LATA2 = 0; // apaga backlight (auto), conserva backlightOn
        }

        if (FinalizarConteo) {
            if (initialized)
                LATE = 0b1010; //Lo pone en magenta puesto que ya fue inicializado
            goto MENU_OBJETIVO;
        }

        if (ReiniciarConteo) {
            ReiniciarConteo = 0;
            counter = 0;
            tens = 0;
            initialized = 1;
            estadoObjeto = 0;
            LATE = 0b1010; // Ya fue inicializado, solo falla de energia deja el led en negro
            LATD = 0;
            counterAnterior = 0xFF;
        }

        // -- HC-SR04: maquina de 2 estados (entra/sale del rango) ---------------
        //   Pieza presente en [DIST_MIN_CM, DIST_MAX_CM] -> estadoObjeto = 1.
        //   Cuando la pieza sale (>DIST_MAX_CM y dist != 255) -> cuenta +1.
        //   Esto reemplaza la deteccion por flanco de bajada del IR original.
        //   255 = sin eco / fuera de rango -> se ignora (no cuenta como salida).
        unsigned char dist = MedirDistancia();

        if (dist >= DIST_MIN_CM && dist <= DIST_MAX_CM) {
            if (estadoObjeto == 0) {
                estadoObjeto = 1;
                if (!initialized) {
                    initialized = 1;
                    LATE = 0b1010; // Magenta: primera pieza detectada
                }
            }
        } else if (dist > DIST_MAX_CM && dist != 255) {
            if (estadoObjeto == 1) {
                estadoObjeto = 0;

                counter++;

                // Una pieza es actividad
                tiempoInactivo = 0; // reinicia el temporizador de inactividad
                LATA2 = backlightOn; // restaura la luz si el auto-off la apago

                // setRGB() maneja internamente el reset de tens (case 6)
                // y la activacion de rangRang, igual que el original.
                if (counter >= 10) {
                    counter = 0;
                    tens++;
                    setRGB();
                }

                LATD = counter & 0x0F;
            }
        }

        if (counter != counterAnterior) {
            counterAnterior = counter;
            unsigned char totalContadas = (unsigned char) (tens * 10 + counter);
            ActualizaLCD(cuentaObjetivo, totalContadas);
            LATD = counter & 0x0F;
        }

        if (rangRang) {
            buzz(0);
            rangRang = 0;
            ringRing = 0;
        } else if (ringRing) {
            buzz(1);
            ringRing = 0;
        }

        __delay_ms(20); // muestreo del ultrasonido cada ~20+ ms
    }
}

// =============================================================================
//  HC-SR04: Medir Distancia
//  Devuelve la distancia en cm, o 255 si no hay eco / fuera de rango.
//  - Envia un pulso TRIGGER de 20 us (el datasheet pide >= 10 us).
//  - Mide la duracion del pulso ECHO con Timer1 + CCP2 (captura por flanco
//    de bajada).
//  - A Fosc = 1 MHz, Tcy = 4 us -> 1 cm de ida y vuelta ~= 58 us ~= 14.5
//    ticks. Por eso dist_cm = CCPR2 / 14 (clamp a 254 cm para no desbordar
//    el byte de retorno).
//  - 'guard' protege contra cuelgues si el sensor no esta conectado.
// =============================================================================

unsigned char MedirDistancia(void) {
    unsigned char aux = 0;
    unsigned int guard;

    CCP2CON = 0b00000100; // CCP2 captura por flanco de bajada
    TMR1 = 0;
    CCP2IF = 0;
    TMR1IF = 0;

    TRIGGER = 1;
    __delay_us(20); // pulso de disparo
    TRIGGER = 0;

    // Espera al flanco de subida del ECHO (con timeout corto anti-cuelgue)
    guard = 0;
    while (ECHO == 0) {
        if (++guard > 1500) return 255;
    }

    // Mide la duracion del pulso ECHO
    TMR1ON = 1;
    while (CCP2IF == 0 && TMR1IF == 0);
    TMR1ON = 0;

    if (TMR1IF == 1) {
        aux = 255; // overflow de Timer1: muy lejos / sin eco valido
        TMR1IF = 0;
    } else {
        if (CCPR2 >= 3556) CCPR2 = 3556; // clamp a ~254 cm
        aux = (unsigned char) (CCPR2 / 14);
    }
    return aux;
}

// =============================================================================
//  BONUS: Graba un patron de 8 filas en la CGRAM del LCD
//  pos  : numero de caracter propio (0..7)
//  mapa : arreglo de 8 bytes (solo importan los 5 bits bajos de cada fila)
//  Despues de grabar, regresa el cursor a DDRAM (obligatorio: si no, todo
//  lo que se escriba seguiria yendo a la CGRAM).
//  El caracter queda disponible escribiendo EscribeLCD_c(pos).
// =============================================================================

void CreaCaracter(unsigned char pos, const unsigned char *mapa) {
    unsigned char i;
    ComandoLCD(0x40 | (unsigned char) (pos << 3)); // Set CGRAM address
    for (i = 0; i < 8; i++) {
        EscribeLCD_c(mapa[i]); // RS=1: escribe el patron
    }
    DireccionaLCD(0x80); // Volver a DDRAM
}

// =============================================================================
//  BONUS 2: Suspension total del sistema (SLEEP)
//  Apaga consumidores visibles (backlight, LED, RGB) SIN borrar el LCD: el
//  controlador HD44780 conserva el texto en DDRAM mientras haya alimentacion,
//  por eso al despertar la pantalla reaparece intacta sin redibujar.
//  Despierta por la interrupcion de cambio en PORTB (teclado), que es
//  asincrona y por tanto valida como fuente de wake-up en SLEEP.
//  Nota: HLVDIE queda habilitado, asi que una caida de voltaje tambien
//  despertaria el sistema. Si solo quieres que el teclado despierte, pon
//  HLVDIE = 0 antes del SLEEP y restauralo despues.
// =============================================================================

void EntrarSuspension(void) {
    // Apagar lo que consume / es visible
    LATA2 = 0; // Backlight OFF
    LATA6 = 0; // LED indicador OFF (antes RA0)
    LATE = 0b1111; // RGB OFF

    // Preparar el despertar por teclado
    backlightOn = 1; // al volver queremos luz
    enSuspension = 1;
    RBIF = 0;
    RBIE = 1;
    GIE = 1;

    asm("SLEEP"); // <<< el PIC se duerme aqui
    asm("NOP"); // se ejecuta al despertar (recomendado tras SLEEP)

    // ---- Continua aqui tras despertar (la ISR de RBIF ya corrio) ----
    enSuspension = 0;
    tiempoInactivo = 0;
    LATA2 = 1; // Backlight ON
    backlightOn = 1;
}

// =============================================================================
//  Actualiza digitos de "Piezas falt:" en el LCD
// =============================================================================

void ActualizaLCD(unsigned char objetivo, unsigned char contadas) {
    unsigned char faltantes;
    faltantes = (contadas >= objetivo) ? 0 : (objetivo - contadas);

    DireccionaLCD(0x8D);
    if (faltantes >= 10) {
        EscribeLCD_c('0' + (faltantes / 10));
        EscribeLCD_c('0' + (faltantes % 10));
    } else {
        EscribeLCD_c(' ');
        EscribeLCD_c('0' + faltantes);
    }
}

// =============================================================================
//  Buzzer en RA3
//  shortBuzz=1 -> corto  (~80 ms,  nueva decena)
//  shortBuzz=0 -> largo  (~1500 ms, 60 piezas completadas)
//  __delay_ms() en XC8 NO es interrupt-safe: se desactiva GIE durante el
//  delay y se restaura al salir.
// =============================================================================

void buzz(unsigned char shortBuzz) {
    GIE = 0; // Deshabilitar interrupciones durante el delay
    LATA3 = 1;
    if (shortBuzz) {
        __delay_ms(80);
    } else {
        __delay_ms(1500);
    }
    LATA3 = 0;
    GIE = 1; // Restaurar interrupciones
}

// =============================================================================
//  Actualiza color del RGB segun decenas (anodo comun: 0=ON, 1=OFF)
//  RE3=1 siempre | RE2=Azul | RE1=Verde | RE0=Rojo
//  El case 6 resetea tens=0, pone Magenta y activa rangRang.
// =============================================================================

void setRGB(void) {
    switch (tens) {
        case 0: LATE = 0b1111;
            break; // Apagado
        case 1: LATE = 0b1011;
            ringRing = 1;
            break; // Azul     (B)
        case 2: LATE = 0b1001;
            ringRing = 1;
            break; // Cyan     (G+B)
        case 3: LATE = 0b1101;
            ringRing = 1;
            break; // Verde    (G)
        case 4: LATE = 0b1100;
            ringRing = 1;
            break; // Amarillo (R+G)
        case 5: LATE = 0b1000;
            ringRing = 1;
            break; // Blanco   (R+G+B)
        case 6: // 60 piezas: resetear ciclo
            tens = 0;
            LATE = 0b1010; // Magenta  (R+B)
            rangRang = 1; // Buzzer largo
            break;
        default: LATE = 0b1111;
            break; // Apagado (seguridad)
    }
}

// =============================================================================
//  ISR DE ALTA PRIORIDAD
//  - Timer0:  conmutacion del LED en RA6 + acumulador de inactividad
//  - HLVD:    deteccion de voltaje bajo -> ajusta Timer0
//  - RBIF:    teclado matricial (emergencia, reinicio, menu, backlight, wake)
// =============================================================================

void interrupt ISR(void) {

    // -- Timer0: conmutacion LED RA6 + cuenta de inactividad ------------------
    if (TMR0IF == 1) {
        TMR0IF = 0;
        TMR0 = tmr0_reload;
        LATA6 = LATA6 ^ 1; // LED indicador conmuta en RA6 (antes RA0)

        // -- Acumular tiempo de inactividad ----------------------------------
        //  El reload define el periodo del desbordamiento: 1000 ms en normal,
        //  250 ms en modo alerta HLVD. Se suma segun el reload activo.
        if (tiempoInactivo < 60000) {
            tiempoInactivo += (tmr0_reload == 57724) ? 250 : 1000;
        }
    }

    // -- HLVD: bajo voltaje ------------------------------------------------------
    if (HLVDIF == 1) {
        HLVDIE = 0;
        if (VDIRMAG == 0) {
            tmr0_reload = 57724; // 250 ms -> parpadeo rapido de alerta
            VDIRMAG = 1;
        } else {
            tmr0_reload = 34286; // 1 s -> normal
            VDIRMAG = 0;
        }
        while (!IRVST);
        HLVDIF = 0;
        HLVDIE = 1;
    }

    // -- RBIF: teclado matricial ---------------------------------------------------
    if (RBIF == 1) {
        if (PORTB != 0b11110000) {

            // -- Barrido de las 4 columnas -------------------------------------
            Tecla = 0;
            LATB = 0b11111110; // Columna 1
            if (PORTBbits.RB4 == 0) Tecla = 13;
            else if (PORTBbits.RB5 == 0) Tecla = 12;
            else if (PORTBbits.RB6 == 0) Tecla = 11;
            else if (PORTBbits.RB7 == 0) Tecla = 10;
            else {
                LATB = 0b11111101; // Columna 2
                if (PORTBbits.RB4 == 0) Tecla = 15;
                else if (PORTBbits.RB5 == 0) Tecla = 9;
                else if (PORTBbits.RB6 == 0) Tecla = 6;
                else if (PORTBbits.RB7 == 0) Tecla = 3;
                else {
                    LATB = 0b11111011; // Columna 3
                    if (PORTBbits.RB4 == 0) Tecla = 0;
                    else if (PORTBbits.RB5 == 0) Tecla = 8;
                    else if (PORTBbits.RB6 == 0) Tecla = 5;
                    else if (PORTBbits.RB7 == 0) Tecla = 2;
                    else {
                        LATB = 0b11110111; // Columna 4
                        if (PORTBbits.RB4 == 0) Tecla = 14;
                        else if (PORTBbits.RB5 == 0) Tecla = 7;
                        else if (PORTBbits.RB6 == 0) Tecla = 4;
                        else if (PORTBbits.RB7 == 0) Tecla = 1;
                    }
                }
            }
            LATB = 0b00000000; // Restaurar columnas

            // -- Cualquier tecla = actividad ----------------------------------
            tiempoInactivo = 0;

            if (enSuspension) {
                // Esta pulsacion solo sirvio para DESPERTAR del SLEEP.
                // No ejecuta la accion normal de la tecla (evita disparar
                // emergencia/reinicio/menu al volver de la suspension).
                enSuspension = 0;
            } else {

                // -- Tecla 11: parada de emergencia ----------------------------
                if (Tecla == 11) {
                    LATE = 0b1110; // Rojo (RE0=0 enciende rojo)

                    BorraLCD();
                    DireccionaLCD(0x80);
                    EscribeLCD_c('!');
                    EscribeLCD_c('!');
                    EscribeLCD_c(' ');
                    EscribeLCD_c('E');
                    EscribeLCD_c('M');
                    EscribeLCD_c('E');
                    EscribeLCD_c('R');
                    EscribeLCD_c('G');
                    EscribeLCD_c('E');
                    EscribeLCD_c('N');
                    EscribeLCD_c('C');
                    EscribeLCD_c('I');
                    EscribeLCD_c('A');
                    EscribeLCD_c(' ');
                    EscribeLCD_c('!');
                    EscribeLCD_c('!');
                    DireccionaLCD(0xC0);
                    EscribeLCD_c('S');
                    EscribeLCD_c('i');
                    EscribeLCD_c('s');
                    EscribeLCD_c('t');
                    EscribeLCD_c('e');
                    EscribeLCD_c('m');
                    EscribeLCD_c('a');
                    EscribeLCD_c(' ');
                    EscribeLCD_c('d');
                    EscribeLCD_c('e');
                    EscribeLCD_c('t');
                    EscribeLCD_c('e');
                    EscribeLCD_c('n');
                    EscribeLCD_c('i');
                    EscribeLCD_c('d');
                    EscribeLCD_c('o');
                    while (1) {
                    } // Bloqueo total: solo sale con MCLR
                }

                // -- Tecla 14: reiniciar conteo -------------------------------
                if (Tecla == 14) {
                    ReiniciarConteo = 1;
                }// -- Tecla 15: volver al menu ---------------------------------
                else if (Tecla == 15) {
                    FinalizarConteo = 1;
                }// -- Tecla de backlight: conmuta el estado deseado ------------
                else if (Tecla == TECLA_BACKLIGHT) {
                    backlightOn ^= 1;
                }// -- Resto de teclas ------------------------------------------
                else {
                    TeclaLista = 1;
                }

                // Aplica el estado deseado del backlight. Esto tambien
                // RESTAURA la luz si el auto-off (10 s) la habia apagado:
                // cualquier tecla devuelve la pantalla a 'backlightOn'.
                LATA2 = backlightOn;
            }
        }
        __delay_ms(100);
        RBIF = 0;
    }
}






